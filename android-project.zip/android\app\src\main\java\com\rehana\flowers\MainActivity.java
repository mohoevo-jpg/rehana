package com.rehana.flowers;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
